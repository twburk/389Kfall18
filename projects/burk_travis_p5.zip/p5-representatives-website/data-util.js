var fs = require('fs');

var abvMap = {
    "Alabama": "AL",
    "Alaska": "AK",
    "Arizona": "AZ",
    "Arkansas": "AR",
    "California": "CA",
    "Colorado": "CO",
    "Connecticut": "CT",
    "Delaware": "DE",
    "District Of Columbia": "DC",
    "Florida": "FL",
    "Georgia": "GA",
    "Hawaii": "HI",
    "Idaho": "ID",
    "Illinois": "IL",
    "Indiana": "IN",
    "Iowa": "IA",
    "Kansas": "KS",
    "Kentucky": "KY",
    "Louisiana": "LA",
    "Maine": "ME",
    "Maryland": "MD",
    "Massachusetts": "MA",
    "Michigan": "MI",
    "Minnesota": "MN",
    "Mississippi": "MS",
    "Missouri": "MO",
    "Montana": "MT",
    "Nebraska": "NE",
    "Nevada": "NV",
    "New Hampshire": "NH",
    "New Jersey": "NJ",
    "New Mexico": "NM",
    "New York": "NY",
    "North Carolina": "NC",
    "North Dakota": "ND",
    "Ohio": "OH",
    "Oklahoma": "OK",
    "Oregon": "OR",
    "Pennsylvania": "PA",
    "Rhode Island": "RI",
    "South Carolina": "SC",
    "South Dakota": "SD",
    "Tennessee": "TN",
    "Texas": "TX",
    "Utah": "UT",
    "Vermont": "VT",
    "Virginia": "VA",
    "Washington": "WA",
    "West Virginia": "WV",
    "Wisconsin": "WI",
    "Wyoming": "WY",
}

function loadData() {
    return JSON.parse(fs.readFileSync('data.json'));
}

/* It is very possible you will need to write other helper
 * methods to make data processing easier. For example, writing 
 * something that converts "Rhode Island" to "rhodeisland" or
 * "rhode-island" could be pretty useful...
 * 
 * Make sure you add all new helper functions to the module.exports.
 */

function getStates(){
    const states = Object.keys(abvMap);
    return states;
}

function getAbr(a){
    return abvMap[a];
}

function getKey(a){
    for(var key in abvMap){
        if(abvMap[key] == a)
            return key;
    }
}

function hasWhiteSpace(s) {
    if(s.indexOf(' ') >= 0)
        return true;
}

function removeWhiteSpace(s){
    var str = s.replace(/\s/g, "");
    return str;
}

module.exports = {
    loadData: loadData,
    getStates: getStates,
    getAbr: getAbr,
    getKey: getKey,
    hasWhiteSpace: hasWhiteSpace,
    removeWhiteSpace: removeWhiteSpace,
}
